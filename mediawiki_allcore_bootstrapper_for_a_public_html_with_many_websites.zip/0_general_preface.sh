#!/bin/bash

## Declare web application variables:
read web_application_root
read domain
read domain_dir # ${web_application_root}/${domain}/public_html (?)
