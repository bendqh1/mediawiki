#!/bin/bash

## Prepare for configurations:
cd "${domain_dir}"
